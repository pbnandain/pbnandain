
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { cloud } from '../services/cloudService';

interface LoginProps {
  onLogin: (userData: any) => void;
}

const LoginPage: React.FC<LoginProps> = ({ onLogin }) => {
  const [manualName, setManualName] = useState('');
  const [manualEmail, setManualEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    /* global google */
    if (typeof (window as any).google !== 'undefined') {
      (window as any).google.accounts.id.initialize({
        client_id: "753822183574-8v5p6v7p6v7p6v7p.apps.googleusercontent.com", // Mock ID - in real apps use your GCP Client ID
        callback: handleGoogleAuth
      });
      (window as any).google.accounts.id.renderButton(
        document.getElementById("google-login-btn"),
        { theme: "outline", size: "large", width: "100%", shape: "pill" }
      );
    }
  }, []);

  // Decodes Google's JWT to get real credentials
  const parseJwt = (token: string) => {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map((c) => {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(jsonPayload);
    } catch (e) {
      return null;
    }
  };

  const handleGoogleAuth = async (response: any) => {
    setIsLoading(true);
    const payload = parseJwt(response.credential);
    if (payload) {
      const user = await cloud.authenticateUser({
        username: payload.name,
        email: payload.email,
        profilePic: payload.picture
      });
      onLogin(user);
    }
    setIsLoading(false);
  };

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName || !manualEmail) return;
    setIsLoading(true);
    const user = await cloud.authenticateUser({
      username: manualName,
      email: manualEmail,
      profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=${manualName}`
    });
    onLogin(user);
    setIsLoading(false);
  };

  const handleMasterAccess = async () => {
    setIsLoading(true);
    const user = await cloud.authenticateUser({
      username: "Prashant Nanda",
      email: "pbnandain@gmail.com",
      isAdmin: true,
      profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=PrashantNanda`
    });
    onLogin(user);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-orange-50 p-6">
      <div className="max-w-md w-full bg-white rounded-[64px] shadow-2xl shadow-indigo-100 p-12 space-y-10 animate-scaleIn border border-white relative overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
            <i className="fa-solid fa-om fa-spin text-5xl text-orange-500 mb-4"></i>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Syncing Cloud Identity...</p>
          </div>
        )}

        <div className="text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="w-20 h-20 bg-slate-900 rounded-[32px] flex items-center justify-center text-white text-3xl shadow-xl shadow-slate-200 rotate-3 hover:rotate-0 transition-transform">
              <i className="fa-solid fa-om"></i>
            </div>
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Hindu Network</h1>
          <p className="text-slate-400 mt-2 font-black text-[10px] uppercase tracking-[0.4em]">Professional Earn & Learn Portal</p>
        </div>

        <div className="space-y-4">
          <div id="google-login-btn" className="w-full"></div>
          
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-100"></span></div>
            <div className="relative flex justify-center text-[8px] uppercase font-black text-slate-400"><span className="bg-white px-4">Or Manual Workspace</span></div>
          </div>

          <form onSubmit={handleManualLogin} className="space-y-4">
            <input 
              type="text" 
              placeholder="Display Name"
              value={manualName}
              onChange={(e) => setManualName(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl px-6 py-4 font-bold text-sm outline-none focus:border-indigo-500 transition-all"
            />
            <input 
              type="email" 
              placeholder="Professional Email"
              value={manualEmail}
              onChange={(e) => setManualEmail(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl px-6 py-4 font-bold text-sm outline-none focus:border-indigo-500 transition-all"
            />
            <button 
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black uppercase tracking-widest text-[10px] py-5 rounded-[24px] transition-all shadow-xl shadow-slate-200"
            >
              Launch Dashboard
            </button>
          </form>
        </div>

        <div className="pt-6 border-t border-slate-50">
          <button 
            onClick={handleMasterAccess}
            className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-[24px] transition-all flex items-center justify-center gap-3 text-[10px] uppercase tracking-widest shadow-lg shadow-orange-100"
          >
            <i className="fa-solid fa-shield-halved"></i>
            Master Access: Prashant Nanda
          </button>
        </div>

        <div className="text-center space-y-4">
           <div className="bg-indigo-50/50 p-6 rounded-[32px] border border-indigo-100">
             <p className="text-[9px] text-indigo-700 font-bold uppercase leading-relaxed tracking-wider">
               Identity System: Connected to Global Registry. 
               <br/>Cloud Sync Enabled for pbnandain@gmail.com
             </p>
           </div>
           <p className="text-[10px] text-slate-300 font-black uppercase tracking-widest">Secure Reverse Auction • 1 COIN = 1 INR</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;

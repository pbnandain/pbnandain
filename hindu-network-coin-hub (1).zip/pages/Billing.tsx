
import React, { useState, useEffect } from 'react';
import { UserProfile, Transaction, TransactionType } from '../types';
import { analyzeAccountingData } from '../services/geminiService';
import { cloud } from '../services/cloudService';

interface BillingProps {
  user: UserProfile;
  transactions: Transaction[];
  onTransaction: (tx: Transaction) => void;
  onUserUpdate: (user: UserProfile) => void;
}

const Billing: React.FC<BillingProps> = ({ user, transactions, onTransaction, onUserUpdate }) => {
  const [analysis, setAnalysis] = useState<string>('Analyzing your account health...');
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  
  const [utr, setUtr] = useState('');
  const [amount, setAmount] = useState('');
  const [userUpi, setUserUpi] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  useEffect(() => {
    const fetchAnalysis = async () => {
      try {
        const text = await analyzeAccountingData(transactions);
        setAnalysis(text);
      } catch (err) {
        setAnalysis("Account overview is temporarily unavailable.");
      } finally {
        setLoading(false);
      }
    };
    fetchAnalysis();
  }, [transactions]);

  const handleSubmitTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    
    if (isNaN(numAmount) || numAmount <= 0) {
      alert("Please enter a valid amount.");
      return;
    }

    if (activeTab === 'withdraw' && numAmount > user.balance) {
      alert("Insufficient balance for withdrawal.");
      return;
    }

    if (utr.length < 10 && activeTab === 'deposit') {
      alert("Please provide a valid 12-digit UPI UTR/Transaction ID.");
      return;
    }

    setIsSubmitting(true);
    
    setTimeout(() => {
      const newTx: Transaction = {
        id: `upi-${Date.now()}`,
        userId: user.id,
        userName: user.username,
        date: new Date().toISOString().split('T')[0],
        amount: numAmount,
        type: activeTab === 'deposit' ? TransactionType.DEPOSIT : TransactionType.WITHDRAWAL,
        description: activeTab === 'deposit' 
          ? `Digital Deposit (UTR: ${utr})` 
          : `Payout Request to ${userUpi}`,
        status: 'Pending',
        utr: activeTab === 'deposit' ? utr : userUpi
      };

      onTransaction(newTx);
      
      if (activeTab === 'withdraw') {
        onUserUpdate({ ...user, balance: user.balance - numAmount });
      }

      alert(activeTab === 'deposit' 
        ? "Payment submitted. Host will reconcile this with the UPI Bank Statement. Balance updates on confirmation." 
        : "Withdrawal requested. Funds will be settled by the Network Host after audit.");
      
      setAmount('');
      setUtr('');
      setUserUpi('');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fadeIn">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Market Wallet</h1>
          <p className="text-slate-500 font-medium">1 COIN = 1 INR • Secure Peer-to-Peer Settlements</p>
        </div>
        <div className="bg-slate-900 text-white p-8 rounded-[40px] shadow-2xl shadow-slate-200 border border-slate-800 flex items-center gap-6">
           <div className="w-14 h-14 bg-orange-600 rounded-2xl flex items-center justify-center text-3xl shadow-lg shadow-orange-900/40">
             <i className="fa-solid fa-wallet"></i>
           </div>
           <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Available Spending Power</p>
              <h2 className="text-3xl font-black text-white">{formatCurrency(user.balance)}</h2>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Settlement Panel */}
        <section className="lg:col-span-2 bg-white rounded-[48px] shadow-sm border border-slate-100 overflow-hidden">
          <div className="flex border-b border-slate-50">
            <button 
              onClick={() => setActiveTab('deposit')}
              className={`flex-1 py-6 font-black text-[10px] uppercase tracking-widest transition-all ${activeTab === 'deposit' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-900'}`}
            >
              Deposit Funds
            </button>
            <button 
              onClick={() => setActiveTab('withdraw')}
              className={`flex-1 py-6 font-black text-[10px] uppercase tracking-widest transition-all ${activeTab === 'withdraw' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-900'}`}
            >
              Withdraw Earnings
            </button>
          </div>

          <div className="p-8 md:p-12">
            <form onSubmit={handleSubmitTransaction} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Amount (₹)</label>
                    <input required type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-6 py-4 font-black text-2xl outline-none focus:border-orange-500 transition-all" />
                  </div>
                  {activeTab === 'deposit' ? (
                    <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">UTR / Ref ID</label>
                      <input required type="text" value={utr} onChange={e => setUtr(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none focus:border-orange-500 transition-all" placeholder="12-digit UPI Number" />
                    </div>
                  ) : (
                    <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Your UPI ID for Payout</label>
                      <input required type="text" value={userUpi} onChange={e => setUserUpi(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none focus:border-orange-500 transition-all" placeholder="username@upi" />
                    </div>
                  )}
                </div>

                {activeTab === 'deposit' && (
                  <div className="bg-orange-50 p-6 rounded-[32px] border border-orange-100 flex flex-col justify-center text-center">
                    <p className="text-[10px] font-black text-orange-600 uppercase tracking-widest mb-2">Send UPI Payment To</p>
                    <p className="text-2xl font-black text-slate-800 mb-1">6359893345@UPI</p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest italic">Host Audited Transfer</p>
                  </div>
                )}
              </div>
              <button disabled={isSubmitting} className="w-full bg-orange-600 hover:bg-orange-700 text-white py-5 rounded-3xl font-black text-xs uppercase tracking-widest transition-all shadow-xl shadow-orange-100">
                {isSubmitting ? <i className="fa-solid fa-spinner fa-spin"></i> : (activeTab === 'deposit' ? 'Confirm Digital Deposit' : 'Initiate Host Payout')}
              </button>
            </form>
          </div>
        </section>

        {/* Insights Panel */}
        <section className="bg-white rounded-[48px] p-10 border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center space-y-6">
           <div className="w-20 h-20 bg-slate-900 text-white rounded-[32px] flex items-center justify-center text-3xl shadow-xl">
             <i className="fa-solid fa-chart-line"></i>
           </div>
           <h3 className="text-xl font-black text-slate-900">Wallet Intelligence</h3>
           <p className={`text-sm text-slate-500 font-medium italic leading-relaxed ${loading ? 'animate-pulse' : ''}`}>
             "{analysis}"
           </p>
        </section>
      </div>

      {/* Ledger */}
      <section className="bg-white rounded-[48px] border border-slate-100 overflow-hidden shadow-sm">
        <div className="p-8 border-b border-slate-50 flex items-center justify-between">
          <h3 className="text-xl font-black text-slate-900">Transaction History</h3>
        </div>
        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                  <th className="px-8 py-6">Reference</th>
                  <th className="px-8 py-6">Type</th>
                  <th className="px-8 py-6">Description</th>
                  <th className="px-8 py-6">Amount</th>
                  <th className="px-8 py-6">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {transactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-6 text-[10px] font-mono text-slate-400">{tx.id}</td>
                    <td className="px-8 py-6">
                       <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                         tx.type === TransactionType.EARNING ? 'bg-green-50 text-green-700 border-green-100' :
                         tx.type === TransactionType.TASK_PAYMENT ? 'bg-orange-50 text-orange-700 border-orange-100' : 'bg-slate-50 text-slate-500 border-slate-100'
                       }`}>
                         {tx.type === TransactionType.TASK_PAYMENT ? 'Hired Work' : (tx.type === TransactionType.EARNING ? 'Project Earn' : tx.type)}
                       </span>
                    </td>
                    <td className="px-8 py-6 text-sm font-medium text-slate-800">{tx.description}</td>
                    <td className={`px-8 py-6 text-lg font-black ${tx.amount > 0 && (tx.type === TransactionType.EARNING || tx.type === TransactionType.DEPOSIT) ? 'text-green-600' : 'text-slate-900'}`}>
                      {tx.amount > 0 && (tx.type === TransactionType.EARNING || tx.type === TransactionType.DEPOSIT) ? '+' : '-'}₹{tx.amount.toLocaleString()}
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                        tx.status === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
           </table>
        </div>
      </section>
    </div>
  );
};

export default Billing;

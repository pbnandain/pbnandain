
import React from 'react';
import { Link } from 'react-router-dom';

const BiddingPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 animate-fadeIn space-y-16 pb-24">
      <section className="text-center space-y-6">
        <div className="inline-block bg-indigo-50 text-indigo-700 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100 mb-2">
          Regulatory Framework
        </div>
        <h1 className="text-6xl font-black text-slate-900 tracking-tighter leading-none">Minimum Bidding Program</h1>
        <p className="text-xl text-slate-500 font-medium leading-relaxed max-w-2xl mx-auto">
          The legal and operational standards for task participation, auctions, and billing on the Hindu Network Professional Portal.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-10 rounded-[56px] border border-slate-100 shadow-sm space-y-6 hover:shadow-xl transition-all">
          <div className="w-14 h-14 bg-indigo-600 text-white rounded-[24px] flex items-center justify-center text-2xl shadow-lg">
            <i className="fa-solid fa-hourglass-half"></i>
          </div>
          <h3 className="text-2xl font-black tracking-tight text-slate-900">Screentime Tax (v1.0)</h3>
          <p className="text-sm text-slate-500 leading-relaxed font-medium">
            To maintain a high-quality professional atmosphere, we initiate login charges at the point of portal entry.
          </p>
          <div className="bg-slate-900 p-6 rounded-3xl text-white">
             <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400 mb-2">Standard Charge</p>
             <p className="text-2xl font-black">1 COIN @ 100 Seconds</p>
             <p className="text-[9px] text-slate-500 mt-2 font-bold uppercase">Deducted from verified wallet balance</p>
          </div>
        </div>

        <div className="bg-white p-10 rounded-[56px] border border-slate-100 shadow-sm space-y-6 hover:shadow-xl transition-all">
          <div className="w-14 h-14 bg-orange-600 text-white rounded-[24px] flex items-center justify-center text-2xl shadow-lg">
            <i className="fa-solid fa-gavel"></i>
          </div>
          <h3 className="text-2xl font-black tracking-tight text-slate-900">Reverse Auction Protocol</h3>
          <p className="text-sm text-slate-500 leading-relaxed font-medium">
            Earners secure mandates by offering the most competitive service rates. The lowest professional bid wins the settlement.
          </p>
          <ul className="space-y-3">
             {[
               "Audited Balance Requirement",
               "Real-time Host Settlement",
               "1:1 INR Wallet Peg",
               "Peer-to-Peer Accountability"
             ].map((item, i) => (
               <li key={i} className="flex items-center gap-3 text-xs font-black text-slate-600 uppercase tracking-widest">
                  <i className="fa-solid fa-check text-orange-500"></i> {item}
               </li>
             ))}
          </ul>
        </div>
      </div>

      <section className="bg-slate-900 p-12 rounded-[64px] text-white space-y-12 relative overflow-hidden">
        <div className="space-y-4 relative z-10">
          <h2 className="text-3xl font-black tracking-tight">Statement Audit & Reconciliation</h2>
          <p className="text-slate-400 font-medium leading-relaxed max-w-2xl">
            All deposits and payouts are strictly dependent on verified UPI bank statements. The Network Host (Auditor) reconciles every UTR before COINs are issued.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
          {[
            { title: "Audit Panel", desc: "Every transaction is logged for Host review." },
            { title: "Host Wallet", desc: "Network taxes fund portal maintenance." },
            { title: "Market Oversight", desc: "Deals can be terminated for policy violations." }
          ].map((card, i) => (
            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-[32px]">
              <h4 className="font-black text-indigo-400 text-xs uppercase tracking-widest mb-2">{card.title}</h4>
              <p className="text-xs text-slate-300 font-medium">{card.desc}</p>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row gap-6 relative z-10">
           <Link to="/explore" className="flex-1 bg-white text-slate-900 py-5 rounded-[24px] font-black text-[10px] uppercase tracking-widest text-center transition-all hover:bg-indigo-50">Search Offered Tasks</Link>
           <Link to="/login" className="flex-1 bg-orange-600 hover:bg-orange-500 text-white py-5 rounded-[24px] font-black text-[10px] uppercase tracking-widest text-center transition-all shadow-xl shadow-orange-950/40">Enter Marketplace</Link>
        </div>
        <i className="fa-solid fa-shield-check absolute -right-20 -bottom-20 text-[400px] opacity-5"></i>
      </section>
    </div>
  );
};

export default BiddingPolicy;


import React, { useState, useEffect, useMemo } from 'react';
import { Task, UserProfile, Bid, TaskStatus } from '../types';
import CountdownTimer from '../components/CountdownTimer';
import Modal from '../components/Modal';

interface AuctionsProps {
  tasks: Task[];
  onBid: (id: string, amount: number, bidderId?: string, bidderName?: string) => void;
  awardTask: (taskId: string, winnerId: string, winnerName: string, amount: number) => void;
  user: UserProfile;
}

const Auctions: React.FC<AuctionsProps> = ({ tasks, onBid, awardTask, user }) => {
  const [sortBy, setSortBy] = useState<'Newest' | 'HighReward' | 'ExpiringSoon'>('Newest');
  const [bidInputs, setBidInputs] = useState<Record<string, number>>({});
  const [bidErrors, setBidErrors] = useState<Record<string, string | null>>({});
  const [pendingBid, setPendingBid] = useState<{ taskId: string, amount: number, taskTitle: string, currentLowest: number } | null>(null);
  const [awardingBid, setAwardingBid] = useState<{ taskId: string, bid: Bid } | null>(null);
  
  const auctionTasks = useMemo(() => {
    const filtered = tasks.filter(t => t.isAuction && t.status !== 'Completed');
    
    return [...filtered].sort((a, b) => {
      if (sortBy === 'HighReward') {
        return (b.highestBid || b.reward) - (a.highestBid || a.reward);
      }
      if (sortBy === 'ExpiringSoon') {
        const aDeadline = a.auctionEndTime || a.deadline || Infinity;
        const bDeadline = b.auctionEndTime || b.deadline || Infinity;
        return aDeadline - bDeadline;
      }
      return b.createdAt - a.createdAt;
    });
  }, [tasks, sortBy]);

  const validateBid = (taskId: string, amount: number, currentLowest: number) => {
    if (user.balance < 1) return "Verified balance required to bid";
    if (amount <= 0) return "Bid must be positive";
    if (amount >= currentLowest) return `Bid must be lower than current: ₹${currentLowest}`;
    return null;
  };

  const handleInputChange = (taskId: string, val: string, currentLowest: number) => {
    const amount = parseInt(val) || 0;
    setBidInputs(prev => ({ ...prev, [taskId]: amount }));
    setBidErrors(prev => ({ ...prev, [taskId]: validateBid(taskId, amount, currentLowest) }));
  };

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  return (
    <div className="space-y-8 animate-fadeIn pb-24">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">Reverse Auction desk</span>
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Peer-to-Peer Task Marketplace</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Active Task Biddings</h1>
          <p className="text-slate-500 font-medium max-w-xl">Winning depends on your competitive rate. Tasks are awarded by the poster based on your bid and reputation.</p>
        </div>

        <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sort By:</label>
          <select 
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-transparent font-black text-xs uppercase text-slate-700 focus:outline-none cursor-pointer"
          >
            <option value="Newest">Newest</option>
            <option value="HighReward">Highest Reward</option>
            <option value="ExpiringSoon">Expiring Soon</option>
          </select>
        </div>
      </header>

      {auctionTasks.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-[48px] border border-slate-100 shadow-sm">
          <div className="w-24 h-24 bg-slate-50 text-slate-200 rounded-full flex items-center justify-center text-4xl mx-auto mb-8">
            <i className="fa-solid fa-list-check"></i>
          </div>
          <h3 className="text-2xl font-black text-slate-800">No Open Tasks</h3>
          <p className="text-slate-500 mt-2">Active tasks will appear here as users post new requirements.</p>
        </div>
      ) : (
        <div className="space-y-12">
          {auctionTasks.map(task => {
            const isCreator = task.creatorId === user.id;
            const currentLowest = task.highestBid || task.reward;
            const myBid = bidInputs[task.id] ?? (currentLowest - 50);
            const error = bidErrors[task.id];
            const isAwarded = task.status === 'Awarded' || task.status === 'In Progress';
            const winnerBid = task.bids?.find(b => b.userId === task.winnerId);

            return (
              <div key={task.id} className={`bg-white rounded-[56px] border overflow-hidden transition-all duration-500 flex flex-col lg:flex-row shadow-2xl ${isAwarded ? 'border-green-200 ring-4 ring-green-50' : 'border-slate-100 hover:shadow-orange-100'}`}>
                {/* Visual Status Panel */}
                <div className={`lg:w-1/3 p-10 text-white flex flex-col justify-between relative overflow-hidden ${isAwarded ? 'bg-indigo-950' : 'bg-slate-900'}`}>
                  <div className="relative z-10 space-y-8">
                    <div>
                       <p className="text-orange-400 text-[10px] font-black uppercase tracking-widest mb-2">Current Lowest Bid</p>
                       <h2 className="text-5xl font-black tracking-tighter text-white">
                         {formatCurrency(currentLowest)}
                       </h2>
                    </div>
                    
                    <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                       <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Starting Reward</p>
                       <p className="text-xl font-bold">₹{task.reward.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="mt-12 relative z-10">
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-3">Bidding Closes In</p>
                    <div className="text-3xl font-mono text-orange-400 bg-white/5 p-4 rounded-2xl border border-white/10 inline-block shadow-inner">
                      <CountdownTimer targetDate={task.auctionEndTime || Date.now() + 86400000} />
                    </div>
                  </div>
                  <i className="fa-solid fa-list-check absolute -right-12 -bottom-12 text-[200px] opacity-10 pointer-events-none rotate-12"></i>
                </div>

                {/* Task & Bidder Desk */}
                <div className="p-10 flex-grow flex flex-col">
                  <div className="mb-8 flex-grow">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest border border-indigo-100">
                        {task.difficulty} Task
                      </span>
                      {task.deadline && (
                        <span className="bg-rose-50 text-rose-700 px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest border border-rose-100 flex items-center gap-1">
                          <i className="fa-solid fa-calendar-day"></i>
                          Due: {new Date(task.deadline).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <h3 className="text-3xl font-black text-slate-900 mb-4 tracking-tight leading-tight">{task.title}</h3>
                    <p className="text-slate-500 leading-relaxed font-medium mb-8 line-clamp-3">{task.description}</p>
                    
                    <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100 shadow-inner">
                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center justify-between">
                         Bid Ledger ({task.bidCount || 0})
                         {isCreator && <span className="text-orange-600">You are the Poster (Review Mode)</span>}
                      </h4>
                      <div className="space-y-4">
                        {task.bids && task.bids.length > 0 ? (
                          task.bids.map((bid, i) => (
                            <div key={bid.id} className="flex items-center justify-between py-4 border-b border-slate-200 last:border-none animate-fadeIn">
                              <div className="flex items-center gap-4">
                                <div className="w-8 h-8 bg-white border-2 border-slate-100 rounded-full flex items-center justify-center text-[10px] font-black text-slate-400">
                                  {i + 1}
                                </div>
                                <span className="font-bold text-slate-800">{bid.userName}</span>
                              </div>
                              <div className="flex items-center gap-6">
                                <span className="font-black text-indigo-600 text-lg">{formatCurrency(bid.amount)}</span>
                                {isCreator && task.status === 'Open' && (
                                  <button 
                                    onClick={() => setAwardingBid({ taskId: task.id, bid })}
                                    className="bg-slate-900 hover:bg-orange-600 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
                                  >
                                    Award Task
                                  </button>
                                )}
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-slate-400 italic text-center py-4">No bids published yet.</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {!isCreator && !isAwarded && (
                    <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-slate-50">
                      <div className="flex-grow">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-2">Your Task Bid (INR)</label>
                        <input 
                          type="number"
                          value={myBid}
                          onChange={(e) => handleInputChange(task.id, e.target.value, currentLowest)}
                          className={`w-full bg-slate-50 border-2 rounded-[24px] px-8 py-5 font-black text-2xl outline-none transition-all ${error ? 'border-red-200 ring-2 ring-red-500/10' : 'border-slate-100 focus:border-orange-500 shadow-inner'}`}
                        />
                        {error && <p className="text-red-500 text-[9px] mt-2 font-black uppercase tracking-widest px-2">{error}</p>}
                      </div>
                      <button 
                        onClick={() => setPendingBid({ taskId: task.id, amount: myBid, taskTitle: task.title, currentLowest })}
                        disabled={!!error || myBid <= 0 || user.balance < 1}
                        className="sm:self-end h-[68px] bg-slate-900 hover:bg-orange-600 disabled:opacity-30 text-white px-12 rounded-[24px] font-black text-xs uppercase tracking-widest transition-all shadow-xl active:scale-95"
                      >
                        Publish Bid
                      </button>
                    </div>
                  )}

                  {isAwarded && (
                    <div className="bg-green-50 p-8 rounded-[40px] border-2 border-green-200 flex items-center justify-between animate-fadeIn">
                      <div>
                        <p className="text-green-800 font-black uppercase tracking-widest text-xs mb-1">Task Secured</p>
                        <p className="text-sm text-green-700 font-medium">Assigned to <span className="font-black underline">{task.winnerName}</span> for {formatCurrency(task.highestBid || 0)}</p>
                      </div>
                      <div className="w-12 h-12 bg-green-500 text-white rounded-full flex items-center justify-center text-xl shadow-lg shadow-green-200">
                        <i className="fa-solid fa-check"></i>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={!!pendingBid}
        onClose={() => setPendingBid(null)}
        onConfirm={() => {
          if (pendingBid) onBid(pendingBid.taskId, pendingBid.amount);
          setPendingBid(null);
        }}
        title="Confirm Task Bid"
        message={`Your bid of ${formatCurrency(pendingBid?.amount || 0)} is a commitment to deliver the task deliverables. If awarded, you must fulfill the task for settlement.`}
        confirmLabel="Publish Bid"
      />

      <Modal
        isOpen={!!awardingBid}
        onClose={() => setAwardingBid(null)}
        onConfirm={() => {
          if (awardingBid) {
            awardTask(awardingBid.taskId, awardingBid.bid.userId, awardingBid.bid.userName, awardingBid.bid.amount);
          }
          setAwardingBid(null);
        }}
        title="Award Task Mandate"
        message={`You are selecting ${awardingBid?.bid.userName} to complete this task at ₹${awardingBid?.bid.amount.toLocaleString()}. This locks the agreement for execution.`}
        confirmLabel="Award & Lock"
      />
    </div>
  );
};

export default Auctions;


import React, { useState, useEffect, useMemo } from 'react';
import { UserProfile, Task, TaskStatus } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import Modal from '../components/Modal';
import { getIndustryInsights, getMarketPulse } from '../services/geminiService';

interface DashboardProps {
  user: UserProfile;
  tasks: Task[];
  onComplete: (id: string, reward: number) => void;
  onOpenPolicy: () => void;
  sessionSeconds: number;
}

const Dashboard: React.FC<DashboardProps> = ({ user, tasks, onComplete, onOpenPolicy, sessionSeconds }) => {
  const navigate = useNavigate();
  const [confirmingTask, setConfirmingTask] = useState<Task | null>(null);
  const [insights, setInsights] = useState<{ text: string, sources: any[], isQuotaLimited?: boolean } | null>(null);
  const [marketPulse, setMarketPulse] = useState<any[]>([]);
  const [loadingInsights, setLoadingInsights] = useState(true);
  
  const [postedSort, setPostedSort] = useState<'Newest' | 'Deadline'>('Newest');
  const [wonSort, setWonSort] = useState<'Newest' | 'Deadline'>('Newest');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [insightData, pulseData] = await Promise.all([
          getIndustryInsights(),
          getMarketPulse()
        ]);
        setInsights(insightData);
        setMarketPulse(pulseData);
      } catch (err) {
        setInsights({ text: "Market liquidity is high. New mandates are being published daily.", sources: [] });
      } finally {
        setLoadingInsights(false);
      }
    };
    fetchData();
  }, []);

  const tasksOffering = useMemo(() => {
    const filtered = tasks.filter(t => t.creatorId === user.id);
    return [...filtered].sort((a, b) => {
      if (postedSort === 'Deadline') {
        return (a.deadline || Infinity) - (b.deadline || Infinity);
      }
      return b.createdAt - a.createdAt;
    });
  }, [tasks, user.id, postedSort]);

  const tasksExecuting = useMemo(() => {
    const filtered = tasks.filter(t => t.winnerId === user.id);
    return [...filtered].sort((a, b) => {
      if (wonSort === 'Deadline') {
        return (a.deadline || Infinity) - (b.deadline || Infinity);
      }
      return b.createdAt - a.createdAt;
    });
  }, [tasks, user.id, wonSort]);

  const availableAuctions = useMemo(() => tasks.filter(t => t.status === 'Open' && t.creatorId !== user.id), [tasks, user.id]);

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;
  const billingProgress = (sessionSeconds % 100);

  const StatusBadge = ({ status }: { status: TaskStatus }) => {
    const configs: Record<TaskStatus, { bg: string, text: string, icon: string, border: string }> = {
      'Open': { bg: 'bg-amber-50', text: 'text-amber-700', icon: 'fa-gavel', border: 'border-amber-200' },
      'In Progress': { bg: 'bg-indigo-50', text: 'text-indigo-700', icon: 'fa-spinner fa-spin', border: 'border-indigo-200' },
      'Evaluating': { bg: 'bg-purple-50', text: 'text-purple-700', icon: 'fa-magnifying-glass', border: 'border-purple-200' },
      'Awarded': { bg: 'bg-blue-50', text: 'text-blue-700', icon: 'fa-award', border: 'border-blue-200' },
      'Completed': { bg: 'bg-green-50', text: 'text-green-700', icon: 'fa-check-double', border: 'border-green-200' },
      'Cancelled': { bg: 'bg-red-50', text: 'text-red-700', icon: 'fa-ban', border: 'border-red-200' }
    };
    const config = configs[status] || configs['Open'];
    return (
      <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-2 border shadow-sm ${config.bg} ${config.text} ${config.border}`}>
        <i className={`fa-solid ${config.icon}`}></i>
        {status}
      </span>
    );
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img 
            src={user.profilePic || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} 
            className="w-16 h-16 rounded-[24px] bg-white border-4 border-white shadow-xl"
            alt="Profile"
          />
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Portal Desk: {user.username}</h1>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-slate-400 font-black text-[10px] uppercase tracking-widest">Network Auditor: {user.isAdmin ? 'MASTER' : 'PROFESSIONAL'}</span>
              <span className="text-indigo-600 font-black text-lg">{formatCurrency(user.balance)}</span>
            </div>
          </div>
        </div>
        <Link to="/create" className="bg-slate-900 hover:bg-orange-600 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl flex items-center gap-2">
          <i className="fa-solid fa-plus-circle"></i> Create Task Concept
        </Link>
      </header>

      {/* Earn & Learn Policy Banner */}
      <section className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-[48px] p-12 text-white relative overflow-hidden shadow-2xl">
         <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center gap-3">
                <span className="bg-orange-600 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">Earning Policy v2.0</span>
                <span className="text-indigo-400 text-[10px] font-black uppercase tracking-widest">1 COIN = 1 INR</span>
              </div>
              <h2 className="text-4xl font-black tracking-tight leading-tight">
                Gather Work. <br/>
                Earn Rewards. <br/>
                <span className="text-orange-500 underline underline-offset-8">Learn Professional Concepts.</span>
              </h2>
              <p className="text-slate-400 font-medium max-w-xl leading-relaxed">
                The Hindu Network portal is built on a commitment-first economy. Every task is a learning mandate. Bidding ensures fair market rates, and our login tax ensures high-intent professional interaction.
              </p>
            </div>
            <div className="bg-white/5 border border-white/10 p-8 rounded-[40px] flex flex-col items-center justify-center text-center space-y-4">
                <div className="relative w-24 h-24">
                   <svg className="w-full h-full -rotate-90">
                     <circle cx="48" cy="48" r="40" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
                     <circle cx="48" cy="48" r="40" fill="transparent" stroke="#f97316" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset={251.2 - (251.2 * billingProgress / 100)} className="transition-all duration-1000" />
                   </svg>
                   <div className="absolute inset-0 flex items-center justify-center text-xl font-black text-white">
                      {100 - billingProgress}
                   </div>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Network Access Cycle</p>
                  <p className="text-[9px] text-orange-500 font-bold uppercase tracking-widest italic">1 COIN Tax @ 100s</p>
                </div>
            </div>
         </div>
         <i className="fa-solid fa-om absolute -right-20 -bottom-20 text-[400px] opacity-5 pointer-events-none -rotate-12"></i>
      </section>

      {/* Task Concept Hub */}
      <section className="bg-white border border-indigo-50 rounded-[56px] p-12 shadow-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row gap-12 items-start">
          <div className="w-20 h-20 bg-indigo-600 text-white rounded-[32px] flex flex-shrink-0 items-center justify-center text-3xl shadow-xl shadow-indigo-100">
            <i className="fa-solid fa-brain"></i>
          </div>
          <div className="flex-grow space-y-8 w-full">
            <div>
              <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">AI Professional Concept Hub</span>
              <h3 className="text-3xl font-black text-slate-900 tracking-tight mt-1">Task Concepts to Master</h3>
              <p className="text-slate-500 text-sm font-medium mt-2">Latest high-demand professional requirements generated in real-time.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {marketPulse.length > 0 ? marketPulse.map((pulse, i) => (
                <div key={i} className="bg-slate-50 p-8 rounded-[40px] border border-slate-100 space-y-4 group hover:bg-white hover:border-orange-200 transition-all hover:shadow-2xl hover:-translate-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">{pulse.trend}</span>
                    <i className="fa-solid fa-arrow-up-right-from-square text-slate-300 group-hover:text-orange-500 transition-colors"></i>
                  </div>
                  <h4 className="text-lg font-black text-slate-800 leading-tight">{pulse.earningPath}</h4>
                  <p className="text-xs font-medium text-slate-500 leading-relaxed">{pulse.practicalRequirement}</p>
                  <div className="pt-4 flex items-center justify-between">
                    <span className="text-[9px] font-black text-slate-400 uppercase">Earning:</span>
                    <span className="text-xs font-black text-orange-600">{pulse.earningPotential}</span>
                  </div>
                </div>
              )) : (
                <div className="col-span-3 text-center py-10 bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-100">
                  <i className="fa-solid fa-spinner fa-spin text-indigo-200 text-3xl mb-4"></i>
                  <p className="text-slate-400 font-black uppercase tracking-widest text-[10px]">Retrieving Network Insights...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-6">
          <div className="flex items-center justify-between pr-4">
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <span className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center text-sm">
                <i className="fa-solid fa-list-check"></i>
              </span>
              Tasks I've Posted
            </h2>
          </div>
          <div className="space-y-4">
            {tasksOffering.length === 0 ? (
              <div className="bg-white border-2 border-dashed border-slate-100 rounded-[40px] p-16 text-center">
                <p className="text-slate-400 font-medium italic mb-6">No active mandates found in your cloud registry.</p>
                <Link to="/create" className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl">Post Mandate</Link>
              </div>
            ) : (
              tasksOffering.map(task => (
                <div key={task.id} className="p-10 bg-white border border-slate-100 rounded-[48px] shadow-sm flex flex-col gap-8 hover:shadow-xl transition-all border-l-8 border-l-indigo-600">
                  <div className="flex justify-between items-start">
                    <div>
                       <h4 className="font-black text-xl text-slate-900 leading-tight mb-2">{task.title}</h4>
                       <div className="flex flex-wrap gap-2">
                          <StatusBadge status={task.status} />
                       </div>
                    </div>
                    <span className="text-2xl font-black text-slate-900">{formatCurrency(task.highestBid || task.reward)}</span>
                  </div>
                  <div className="flex gap-4">
                    {task.status === 'In Progress' && (
                      <button onClick={() => setConfirmingTask(task)} className="flex-1 bg-green-600 hover:bg-green-700 text-white py-4 rounded-3xl font-black text-[10px] uppercase tracking-widest shadow-lg">Verify Completion</button>
                    )}
                    <Link to={`/task/${task.id}`} className="flex-1 text-center py-4 border-2 border-slate-100 text-slate-900 rounded-3xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all">View Bids</Link>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="space-y-6">
          <div className="flex items-center justify-between pr-4">
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <span className="w-10 h-10 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center text-sm">
                <i className="fa-solid fa-award"></i>
              </span>
              Tasks I've Secured
            </h2>
          </div>
          <div className="space-y-4">
            {tasksExecuting.length === 0 ? (
              <div className="bg-white border-2 border-dashed border-slate-100 rounded-[40px] p-16 text-center">
                <p className="text-slate-400 font-medium italic mb-6">Explore the Auction Desk to secure your first mandate.</p>
                <Link to="/auctions" className="bg-orange-600 text-white px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl">Go to Auction Desk</Link>
              </div>
            ) : (
              tasksExecuting.map(task => (
                <div key={task.id} className="p-10 bg-white border border-slate-100 rounded-[48px] shadow-sm flex flex-col gap-8 hover:shadow-xl transition-all border-l-8 border-l-green-600">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-black text-xl text-slate-900 leading-tight mb-2">{task.title}</h4>
                      <div className="flex flex-wrap gap-2">
                        <StatusBadge status={task.status} />
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3 py-1 bg-slate-50 rounded-lg">Host: {task.creatorName}</span>
                      </div>
                    </div>
                    <span className="text-2xl font-black text-green-600">{formatCurrency(task.highestBid || task.reward)}</span>
                  </div>
                  <Link to={`/task/${task.id}`} className="text-center py-4 bg-slate-900 text-white rounded-3xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-600 transition-all shadow-xl">Launch Project Brief</Link>
                </div>
              ))
            )}
          </div>
        </section>
      </div>

      <Modal
        isOpen={!!confirmingTask}
        onClose={() => setConfirmingTask(null)}
        onConfirm={() => confirmingTask && onComplete(confirmingTask.id, confirmingTask.highestBid || confirmingTask.reward)}
        title="Approve & Settle"
        message={`Verify deliverables for "${confirmingTask?.title}". This releases ₹${(confirmingTask?.highestBid || confirmingTask?.reward || 0).toLocaleString()} from Cloud Escrow to the Fulfiller.`}
        confirmLabel="Finalize Settlement"
      />
    </div>
  );
};

export default Dashboard;

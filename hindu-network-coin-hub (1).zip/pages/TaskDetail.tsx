
import React, { useMemo, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Task, UserProfile, TaskStatus } from '../types';
import Modal from '../components/Modal';

interface TaskDetailProps {
  tasks: Task[];
  onComplete: (id: string, reward: number) => void;
  onStatusUpdate: (id: string, status: TaskStatus) => void;
  onUpdateTask: (id: string, updates: Partial<Task>) => void;
  user: UserProfile;
  onBid: (id: string, amount: number) => void;
}

const TaskDetail: React.FC<TaskDetailProps> = ({ tasks, onComplete, onStatusUpdate, user, onBid }) => {
  const { taskId } = useParams<{ taskId: string }>();
  const navigate = useNavigate();
  const [confirmingComplete, setConfirmingComplete] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [bidValue, setBidValue] = useState<number>(0);
  const [bidError, setBidError] = useState<string | null>(null);

  const task = useMemo(() => tasks.find(t => t.id === taskId), [tasks, taskId]);

  if (!task) return <div className="text-center py-20 font-bold">Task not found</div>;

  const isOwner = user.id === task.creatorId;
  const currentLowest = task.highestBid || task.reward;
  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  const handleMarkComplete = () => {
    onComplete(task.id, task.highestBid || task.reward);
    navigate('/');
  };

  const handleBidSubmit = () => {
    if (bidValue >= currentLowest) {
      setBidError(`Bid must be lower than ${formatCurrency(currentLowest)}`);
      return;
    }
    if (bidValue <= 0) {
      setBidError("Bid must be positive");
      return;
    }
    onBid(task.id, bidValue);
    setBidValue(0);
    setBidError(null);
  };

  const getStatusConfig = (status: TaskStatus) => {
    switch (status) {
      case 'Open':
        return { label: 'Bidding Active', color: 'bg-amber-500', icon: 'fa-gavel', step: 1 };
      case 'Awarded':
        return { label: 'Awarded', color: 'bg-blue-500', icon: 'fa-award', step: 2 };
      case 'In Progress':
        return { label: 'In Progress', color: 'bg-indigo-500', icon: 'fa-spinner fa-spin', step: 2 };
      case 'Completed':
        return { label: 'Settled', color: 'bg-green-500', icon: 'fa-circle-check', step: 3 };
      default:
        return { label: status, color: 'bg-slate-500', icon: 'fa-circle-question', step: 0 };
    }
  };

  const statusConfig = getStatusConfig(task.status);
  const postedDate = new Date(task.createdAt).toLocaleDateString('en-IN', { 
    day: 'numeric', 
    month: 'short', 
    year: 'numeric' 
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 animate-fadeIn">
      {/* Task Header */}
      <div className="bg-slate-900 rounded-[40px] p-8 text-white flex flex-col lg:flex-row justify-between items-center gap-8 shadow-2xl">
        <div className="flex items-center gap-6">
          <div className={`w-16 h-16 ${statusConfig.color} text-white rounded-[24px] flex items-center justify-center text-3xl shadow-xl`}>
            <i className={`fa-solid ${statusConfig.icon}`}></i>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Task Bidding Desk</p>
              <span className="text-slate-600 opacity-50">•</span>
              <Link 
                to={isOwner ? "/profile" : `/profile?userId=${task.creatorId}`} 
                className="text-[10px] font-black uppercase tracking-widest text-orange-400 hover:text-orange-300 transition-colors"
              >
                {task.creatorName || 'Anonymous Offeror'}
              </Link>
              <span className="text-slate-600 opacity-50">•</span>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Posted {postedDate}</p>
            </div>
            <h2 className="text-3xl font-black">{task.title}</h2>
          </div>
        </div>
        <div className="text-center lg:text-right">
          <p className="text-[10px] font-black uppercase text-slate-400 mb-1">Current Lowest Bid</p>
          <h3 className="text-5xl font-black text-amber-400">{formatCurrency(currentLowest)}</h3>
        </div>
      </div>

      {/* Main Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-10 rounded-[48px] border border-slate-100 shadow-sm space-y-8">
            <div className="space-y-4">
              <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <i className="fa-solid fa-scroll"></i> Task Scope & Deliverables
              </h4>
              <p className="text-slate-600 text-lg font-medium leading-relaxed whitespace-pre-wrap">{task.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
               <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Complexity</p>
                  <p className="font-black text-slate-800">{task.difficulty}</p>
               </div>
               <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Estimated Time</p>
                  <p className="font-black text-slate-800">{task.estimatedTime}</p>
               </div>
            </div>
          </div>

          {/* Participant Ledger */}
          <div className="bg-white p-10 rounded-[48px] border border-slate-100 shadow-sm space-y-6">
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
              Bid Ledger ({task.bidCount || 0})
              <span className="text-indigo-600">Max Budget: {formatCurrency(task.reward)}</span>
            </h4>
            <div className="space-y-4">
              {task.bids && task.bids.length > 0 ? (
                task.bids.map((bid, i) => (
                  <div key={bid.id} className="flex items-center justify-between py-4 border-b border-slate-50 last:border-none">
                    <div className="flex items-center gap-4">
                      <span className="text-[10px] font-black text-slate-300">#{i+1}</span>
                      <Link to={`/profile?userId=${bid.userId}`} className="font-black text-slate-800 hover:text-orange-600 transition-colors">
                        {bid.userName}
                      </Link>
                    </div>
                    <span className="font-black text-indigo-600 text-lg">{formatCurrency(bid.amount)}</span>
                  </div>
                ))
              ) : (
                <p className="text-sm text-slate-400 italic text-center py-6">No bids placed yet. Be the first!</p>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          {!isOwner && task.status === 'Open' && (
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-xl space-y-6">
              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-widest text-center">Submit Your Bid</h4>
              <div className="space-y-2">
                <div className="relative">
                  <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-xl text-slate-300">₹</span>
                  <input 
                    type="number" 
                    value={bidValue || ''} 
                    onChange={e => setBidValue(parseInt(e.target.value))}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl pl-12 pr-6 py-5 font-black text-2xl outline-none focus:border-orange-500 shadow-inner"
                    placeholder="Enter bid..."
                  />
                </div>
                {bidError && <p className="text-red-500 text-[10px] font-bold px-2">{bidError}</p>}
              </div>
              <button 
                onClick={handleBidSubmit}
                className="w-full bg-slate-900 hover:bg-orange-600 text-white py-5 rounded-3xl font-black text-[11px] uppercase tracking-widest transition-all shadow-xl active:scale-95"
              >
                Publish Bid
              </button>
              <p className="text-[9px] text-slate-400 text-center italic font-medium">Bids must be lower than {formatCurrency(currentLowest)}</p>
            </div>
          )}

          {isOwner && task.status === 'Open' && (
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-xl space-y-4">
              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-widest text-center">Owner Controls</h4>
              <button 
                onClick={() => onStatusUpdate(task.id, 'In Progress')}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-5 rounded-3xl font-black text-[11px] uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-play"></i>
                Start Task Execution
              </button>
              <p className="text-[9px] text-slate-400 text-center italic font-medium leading-relaxed">
                Manually transition this task to in-progress mode. The lowest bid will be awarded.
              </p>
            </div>
          )}

          {isOwner && task.status === 'In Progress' && (
            <button 
              onClick={() => setConfirmingComplete(true)}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-6 rounded-[32px] font-black text-lg shadow-xl active:scale-95 transition-all"
            >
              Verify & Settle Task
            </button>
          )}

          {task.status === 'Completed' && (
             <div className="bg-green-50 border-2 border-green-100 p-8 rounded-[40px] text-center space-y-2">
                <i className="fa-solid fa-circle-check text-green-600 text-3xl"></i>
                <h5 className="font-black text-green-900 uppercase text-xs tracking-widest">Task Settled</h5>
                <p className="text-[10px] text-green-700 font-medium">Final payout of {formatCurrency(task.highestBid || task.reward)} processed.</p>
             </div>
          )}

          <div className="bg-indigo-50 p-6 rounded-[40px] border border-indigo-100 space-y-4">
             <div className="flex items-center gap-3">
               <i className="fa-solid fa-shield-halved text-indigo-600"></i>
               <h5 className="text-[10px] font-black text-indigo-900 uppercase">Task Policy</h5>
             </div>
             <p className="text-[11px] text-indigo-800 font-medium leading-relaxed">
               Funds are held in Escrow once the task is awarded. Payout occurs strictly upon verification of task deliverables.
             </p>
          </div>
        </div>
      </div>

      <Modal
        isOpen={confirmingComplete}
        onClose={() => setConfirmingComplete(false)}
        onConfirm={handleMarkComplete}
        title="Finalize Task"
        message={`Confirm task completion for "${task.title}". This releases ₹${(task.highestBid || task.reward).toLocaleString()} to the fulfiller immediately.`}
        confirmLabel="Release Payout"
      />
    </div>
  );
};

export default TaskDetail;


import React, { useRef } from 'react';
import { UserProfile, Transaction, Task } from '../types';
import { cloud } from '../services/cloudService';

interface ProfileProps {
  user: UserProfile;
  tasks: Task[];
  transactions: Transaction[];
  onLogout: () => void;
  onUpdateUser: (user: UserProfile) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, tasks, transactions, onLogout, onUpdateUser }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const activeProjects = tasks.filter(t => t.status === 'In Progress' && t.winnerId === user.id);
  const earnings = transactions
    .filter(tx => tx.status === 'Completed' && (tx.type === 'TASK_PAYMENT' || tx.type === 'EARNING'))
    .reduce((acc, tx) => acc + tx.amount, 0);

  const handleProfilePicUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        alert("Please upload a picture smaller than 1MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const updatedUser = { ...user, profilePic: base64String };
        onUpdateUser(updatedUser);
        cloud.syncUserProfile(updatedUser);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      {/* Profile Header */}
      <section className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-xl flex flex-col md:flex-row items-center gap-8 relative overflow-hidden">
        <div className="relative group cursor-pointer" onClick={triggerFileInput}>
          <img 
            src={user.profilePic || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} 
            alt="Profile" 
            className="w-32 h-32 rounded-[40px] object-cover border-4 border-orange-50 transition-all group-hover:brightness-75"
          />
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <i className="fa-solid fa-camera text-white text-2xl"></i>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-orange-600 border-4 border-white w-10 h-10 rounded-2xl flex items-center justify-center text-white text-lg shadow-lg">
            <i className="fa-solid fa-briefcase"></i>
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleProfilePicUpload} 
            accept="image/*" 
            className="hidden" 
          />
        </div>
        
        <div className="flex-grow text-center md:text-left space-y-4">
          <div>
            <h1 className="text-4xl font-black text-slate-900 tracking-tight">{user.username}</h1>
            <p className="text-slate-500 font-medium">{user.email}</p>
          </div>
          <div className="flex flex-wrap justify-center md:justify-start gap-2">
            <span className="px-4 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 border bg-slate-100 text-slate-500 border-slate-200">
              Verified Professional
            </span>
            {user.isAdmin && (
              <span className="bg-indigo-600 text-white px-4 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-indigo-500">
                Network Host
              </span>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button 
            onClick={onLogout}
            className="bg-slate-900 hover:bg-red-600 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl shadow-slate-200"
          >
            Sign Out
          </button>
        </div>
        
        <i className="fa-solid fa-om absolute -bottom-10 -right-10 text-[200px] opacity-5 -z-0"></i>
      </section>

      {/* Professional Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl space-y-8 border border-slate-800">
          <h3 className="text-xl font-black tracking-tight">Earning Performance</h3>
          
          <div className="space-y-6">
            <div className="bg-white/5 border border-white/10 p-6 rounded-[32px]">
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Total Project Income</p>
              <h4 className="text-4xl font-black text-orange-400">₹{earnings.toLocaleString('en-IN')}</h4>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 border border-white/10 p-6 rounded-[32px]">
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Active Projects</p>
                <h4 className="text-2xl font-black">{activeProjects.length}</h4>
              </div>
              <div className="bg-white/5 border border-white/10 p-6 rounded-[32px]">
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Projects Finished</p>
                <h4 className="text-2xl font-black">{user.completedTasks}</h4>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-[40px] p-8 border border-slate-100 shadow-sm space-y-6 flex flex-col justify-center">
          <h3 className="text-xl font-black text-slate-800 tracking-tight">Network Policy Compliance</h3>
          <div className="bg-orange-50 border border-orange-100 p-8 rounded-[32px] space-y-4">
            <div className="flex items-center gap-4 text-orange-700">
               <i className="fa-solid fa-circle-exclamation text-2xl"></i>
               <span className="text-sm font-black uppercase tracking-widest">Strict Earning Rules</span>
            </div>
            <p className="text-sm text-orange-800 font-medium leading-relaxed">
              Hindu Network maintains a professional-only earning policy. COINs are only credited upon the successful completion of a task and subsequent verification by the task offerer (Host).
            </p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">1 COIN = 1 INR FIXED RATE</p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Profile;

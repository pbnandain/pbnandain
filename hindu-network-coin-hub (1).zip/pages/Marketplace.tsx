
import React, { useState, useMemo } from 'react';
import { Task, UserProfile, TaskStatus } from '../types';
import { useNavigate } from 'react-router-dom';

interface MarketplaceProps {
  tasks: Task[];
  onComplete: (id: string, reward: number) => void;
  user: UserProfile;
  onAddTask: (task: Task) => void;
}

const Marketplace: React.FC<MarketplaceProps> = ({ tasks, onComplete, user, onAddTask }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [amountQuery, setAmountQuery] = useState('');
  const [sortBy, setSortBy] = useState<'Newest' | 'HighReward' | 'ExpiringSoon'>('Newest');
  
  const marketTasks = useMemo(() => tasks.filter(t => !t.isAuction && (t.status === 'Open' || t.status === 'Completed')), [tasks]);

  const filteredTasks = useMemo(() => {
    let result = marketTasks.filter(t => {
      const matchesText = 
        t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.creatorName || '').toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesAmount = amountQuery === '' || t.reward === parseInt(amountQuery);
      
      return matchesText && matchesAmount;
    });

    result.sort((a, b) => {
      if (sortBy === 'HighReward') return b.reward - a.reward;
      if (sortBy === 'ExpiringSoon') {
        return (a.deadline || a.auctionEndTime || Infinity) - (b.deadline || b.auctionEndTime || Infinity);
      }
      return b.createdAt - a.createdAt;
    });

    return result;
  }, [marketTasks, searchQuery, amountQuery, sortBy]);

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  const StatusBadge = ({ status }: { status: TaskStatus }) => {
    const isCompleted = status === 'Completed';
    return (
      <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border flex items-center gap-2 ${
        isCompleted 
        ? 'bg-green-50 text-green-700 border-green-100 shadow-sm' 
        : 'bg-amber-50 text-amber-700 border-amber-100 shadow-sm'
      }`}>
        <i className={`fa-solid ${isCompleted ? 'fa-check-double' : 'fa-bolt-lightning'}`}></i>
        {isCompleted ? 'Mandate Settled' : 'Mandate Active'}
      </span>
    );
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Direct Earning Hub</h1>
          <p className="text-slate-500 font-medium">Fixed-reward professional opportunities across the network.</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 flex-grow max-w-3xl">
          <div className="flex-grow relative">
            <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input 
              type="text"
              placeholder="Filter by title, scope or host..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-[24px] focus:ring-2 focus:ring-orange-500 shadow-sm font-bold text-sm outline-none transition-all"
            />
          </div>
          <div className="w-full md:w-48 relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-400">₹</span>
            <input 
              type="number"
              placeholder="Exact Reward"
              value={amountQuery}
              onChange={(e) => setAmountQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-4 bg-white border border-slate-200 rounded-[24px] focus:ring-2 focus:ring-orange-500 shadow-sm font-bold text-sm outline-none transition-all"
            />
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTasks.length === 0 ? (
          <div className="col-span-full py-24 text-center bg-white rounded-[48px] border border-slate-100 shadow-inner">
            <p className="text-slate-400 font-black uppercase tracking-widest text-xs">No matching mandates currently listed.</p>
          </div>
        ) : (
          filteredTasks.map(task => {
            const isCompleted = task.status === 'Completed';
            return (
              <div 
                key={task.id} 
                className={`p-10 rounded-[48px] border transition-all cursor-pointer hover:shadow-2xl hover:-translate-y-1 flex flex-col group relative overflow-hidden ${isCompleted ? 'bg-green-50/20 border-green-100 opacity-80' : 'bg-white border-slate-100 shadow-sm'}`}
                onClick={() => navigate(`/task/${task.id}`)}
              >
                <div className="flex justify-between items-start mb-8">
                  <StatusBadge status={task.status} />
                  <span className={`text-2xl font-black ${isCompleted ? 'text-slate-400' : 'text-slate-900'}`}>{formatCurrency(task.reward)}</span>
                </div>
                <h3 className={`text-xl font-black mb-4 leading-tight group-hover:text-orange-600 transition-colors ${isCompleted ? 'text-slate-500' : 'text-slate-800'}`}>{task.title}</h3>
                <p className={`text-sm flex-grow mb-10 font-medium line-clamp-3 leading-relaxed ${isCompleted ? 'text-slate-400' : 'text-slate-500'}`}>{task.description}</p>
                
                <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <i className="fa-solid fa-business-time"></i> {task.estimatedTime}
                  </span>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest truncate max-w-[120px]">
                    By {task.creatorName}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Marketplace;


import React, { useState, useMemo, useEffect } from 'react';
import { Task } from '../types';
import { cloud } from '../services/cloudService';
import { Link } from 'react-router-dom';

const PublicDirectory: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const data = await cloud.fetchGlobalTasks();
      setTasks(data.filter(t => t.status === 'Open'));
      setLoading(false);
    };
    load();
  }, []);

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      return t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
             t.description.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [tasks, searchQuery]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 animate-fadeIn space-y-12 pb-24">
      <header className="text-center space-y-4">
        <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-200">Open Earning Ledger</span>
        <h1 className="text-5xl font-black text-slate-900 tracking-tight">Active Earning Mandates</h1>
        <p className="text-slate-500 max-w-2xl mx-auto font-medium">Public view of professional opportunities. Log in to bid or offer.</p>
      </header>

      <div className="max-w-2xl mx-auto relative">
        <i className="fa-solid fa-magnifying-glass absolute left-6 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input 
          type="text" 
          placeholder="Search by skill or project name..." 
          value={searchQuery} 
          onChange={(e) => setSearchQuery(e.target.value)} 
          className="w-full pl-16 pr-6 py-6 bg-white border-2 border-slate-100 rounded-[32px] shadow-xl outline-none focus:border-orange-500 font-bold text-lg" 
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><i className="fa-solid fa-om fa-spin text-5xl text-orange-200"></i></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTasks.map(task => (
            <div key={task.id} className="bg-white p-8 rounded-[48px] border border-slate-50 shadow-sm hover:shadow-2xl transition-all group relative">
              <div className="flex justify-between items-start mb-6">
                <span className="bg-indigo-50 px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest text-indigo-600">Earning Offer</span>
                <span className="font-black text-2xl text-slate-900">₹{task.reward.toLocaleString()}</span>
              </div>
              <h3 className="text-xl font-black text-slate-800 mb-4 group-hover:text-orange-600 transition-colors">{task.title}</h3>
              <p className="text-sm text-slate-500 font-medium line-clamp-3 mb-8">{task.description}</p>
              <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase">{task.creatorName}</span>
                <Link to="/login" className="bg-slate-900 text-white px-5 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg">Enter Bid</Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PublicDirectory;

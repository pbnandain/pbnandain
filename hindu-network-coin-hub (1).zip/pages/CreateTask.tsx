
import React, { useState, useMemo } from 'react';
import { Task, SelectionMethod, UserProfile } from '../types';
import { useNavigate } from 'react-router-dom';
import { refineTaskDetails, suggestTaskSpecs } from '../services/geminiService';

interface CreateTaskProps {
  onAdd: (task: Task) => void;
  user: UserProfile;
}

type WizardStep = 1 | 2 | 3 | 4;

const CreateTask: React.FC<CreateTaskProps> = ({ onAdd, user }) => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState<WizardStep>(1);
  const [refiningAI, setRefiningAI] = useState(false);
  const [suggestingSpecs, setSuggestingSpecs] = useState(false);
  const [proposedRefinement, setProposedRefinement] = useState<any | null>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    reward: 1000,
    difficulty: 'Intermediate' as 'Basic' | 'Intermediate' | 'High-Value',
    estimatedTime: '4 hours',
    isAuction: true,
    selectionMethod: 'Manual' as SelectionMethod,
    deadline: ''
  });

  const deadlineWarning = useMemo(() => {
    if (!formData.deadline) return null;
    const deadlineDate = new Date(formData.deadline).getTime();
    const now = Date.now();
    const diffHours = (deadlineDate - now) / (1000 * 60 * 60);

    if (diffHours <= 0) return { type: 'error', message: 'Deadline must be in the future.' };
    if (diffHours < 24) return { type: 'warning', message: 'Short window might limit quality bids.' };
    return null;
  }, [formData.deadline]);

  const canMoveToNext = () => {
    if (currentStep === 1) return formData.title.length > 5 && formData.description.length > 20;
    if (currentStep === 2) return formData.deadline !== '' && deadlineWarning?.type !== 'error';
    if (currentStep === 3) return formData.reward > 0;
    return true;
  };

  const handleSubmit = () => {
    if (user.balance < formData.reward) {
       alert("Insufficient audited balance to post this task.");
       return;
    }

    const newTask: Task = {
      ...formData,
      id: `task-${Date.now()}`,
      creatorId: user.id,
      creatorName: user.username,
      status: 'Open',
      createdAt: Date.now(),
      highestBid: formData.reward,
      bidCount: 0,
      bids: [],
      auctionEndTime: new Date(formData.deadline).getTime(),
      deadline: new Date(formData.deadline).getTime()
    };
    onAdd(newTask);
    navigate('/auctions');
  };

  const handleRefineWithAI = async () => {
    if (!formData.title || !formData.description) return;
    setRefiningAI(true);
    try {
      const result = await refineTaskDetails({
        title: formData.title,
        description: formData.description,
        reward: formData.reward
      });
      if (result.suggestion) {
        setProposedRefinement(result.suggestion);
      }
    } catch (err) {
      alert("AI Guidance currently busy. Proceeding with manual input.");
    } finally {
      setRefiningAI(false);
    }
  };

  const handleSuggestSpecs = async () => {
    if (!formData.title) return;
    setSuggestingSpecs(true);
    try {
      const specs = await suggestTaskSpecs(formData.title, formData.description);
      setFormData(prev => ({ ...prev, ...specs }));
    } finally {
      setSuggestingSpecs(false);
    }
  };

  const steps = [
    { num: 1, label: 'Task Identity', icon: 'fa-id-card' },
    { num: 2, label: 'Blueprint', icon: 'fa-clock' },
    { num: 3, label: 'Economics', icon: 'fa-coins' },
    { num: 4, label: 'Launch', icon: 'fa-rocket' },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-10 pb-20 animate-fadeIn">
      {/* Wizard Header */}
      <header className="text-center space-y-4">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight uppercase">Task Creation Wizard</h1>
        <div className="flex justify-between items-center max-w-lg mx-auto relative pt-4">
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 -z-10" />
          {steps.map((s) => (
            <div key={s.num} className="flex flex-col items-center gap-2">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-black transition-all ${
                currentStep >= s.num ? 'bg-orange-600 text-white shadow-lg shadow-orange-100' : 'bg-slate-100 text-slate-400'
              }`}>
                {currentStep > s.num ? <i className="fa-solid fa-check"></i> : s.num}
              </div>
              <span className={`text-[9px] font-black uppercase tracking-widest ${currentStep >= s.num ? 'text-slate-900' : 'text-slate-400'}`}>
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </header>

      {/* Step Container */}
      <div className="bg-white p-10 md:p-14 rounded-[56px] border border-slate-100 shadow-2xl relative min-h-[500px] flex flex-col justify-between">
        
        {currentStep === 1 && (
          <div className="space-y-8 animate-slideUpFade">
            <div className="flex justify-between items-end">
               <div>
                 <h2 className="text-2xl font-black text-slate-900">Define Your Task</h2>
                 <p className="text-slate-500 text-sm font-medium">Be specific to attract professional bidders.</p>
               </div>
               <button 
                type="button" 
                onClick={handleRefineWithAI} 
                disabled={refiningAI || formData.title.length < 5}
                className="bg-indigo-600 hover:bg-orange-600 disabled:opacity-30 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg active:scale-95"
              >
                {refiningAI ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-wand-magic-sparkles"></i>}
                AI Clear Guide
              </button>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Task Title</label>
                <input 
                  autoFocus
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})} 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[24px] px-8 py-5 font-black text-lg outline-none focus:border-orange-500 transition-all shadow-inner" 
                  placeholder="e.g. Sales Lead Generation - Bangalore" 
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Description & Deliverables</label>
                <textarea 
                  required 
                  rows={6} 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})} 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[24px] px-8 py-6 font-medium outline-none focus:border-orange-500 transition-all shadow-inner leading-relaxed" 
                  placeholder="Specify exactly what needs to be done and how you will verify completion..." 
                />
              </div>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-8 animate-slideUpFade">
            <div>
              <h2 className="text-2xl font-black text-slate-900">Task Blueprint</h2>
              <p className="text-slate-500 text-sm font-medium">Configure scheduling and complexity.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Bidding Deadline</label>
                <input 
                  type="datetime-local" 
                  value={formData.deadline} 
                  onChange={e => setFormData({...formData, deadline: e.target.value})} 
                  className={`w-full bg-slate-50 border-2 rounded-[24px] px-8 py-5 font-black outline-none transition-all shadow-inner ${deadlineWarning?.type === 'error' ? 'border-red-400' : 'border-slate-100 focus:border-orange-500'}`} 
                />
                {deadlineWarning && <p className={`text-[9px] font-black uppercase px-2 mt-2 ${deadlineWarning.type === 'error' ? 'text-red-500' : 'text-orange-500'}`}>{deadlineWarning.message}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Difficulty Tier</label>
                <select 
                  value={formData.difficulty} 
                  onChange={e => setFormData({...formData, difficulty: e.target.value as any})} 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[24px] px-8 py-5 font-black outline-none cursor-pointer appearance-none shadow-inner"
                >
                  <option value="Basic">Basic Execution</option>
                  <option value="Intermediate">Professional Mandate</option>
                  <option value="High-Value">Specialized Consulting</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Time Estimate</label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={formData.estimatedTime} 
                    onChange={e => setFormData({...formData, estimatedTime: e.target.value})} 
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-[24px] px-8 py-5 font-black outline-none focus:border-orange-500 shadow-inner" 
                    placeholder="e.g. 48 hours" 
                  />
                  <button type="button" onClick={handleSuggestSpecs} className="absolute right-6 top-1/2 -translate-y-1/2 text-indigo-500">
                    <i className={`fa-solid ${suggestingSpecs ? 'fa-spinner fa-spin' : 'fa-magic'}`}></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-8 animate-slideUpFade">
            <div>
              <h2 className="text-2xl font-black text-slate-900">Economic Config</h2>
              <p className="text-slate-500 text-sm font-medium">Set the maximum reward. Bidding will start here.</p>
            </div>

            <div className="max-w-md mx-auto space-y-6">
               <div className="relative">
                 <span className="absolute left-10 top-1/2 -translate-y-1/2 text-4xl font-black text-slate-300">₹</span>
                 <input 
                  type="number" 
                  value={formData.reward} 
                  onChange={e => setFormData({...formData, reward: parseInt(e.target.value) || 0})} 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[40px] pl-20 pr-10 py-10 font-black text-6xl outline-none focus:border-orange-500 shadow-inner text-center" 
                />
               </div>
               <div className="bg-orange-50 p-6 rounded-[32px] border border-orange-100">
                 <p className="text-[10px] font-black text-orange-600 uppercase tracking-widest mb-2 flex items-center gap-2">
                   <i className="fa-solid fa-circle-info"></i> Earning Policy
                 </p>
                 <p className="text-xs text-orange-900 font-medium leading-relaxed">
                   This reward will be locked in Escrow. The **Reverse Auction** ensures you get the best market rate for your task.
                 </p>
               </div>
            </div>
          </div>
        )}

        {currentStep === 4 && (
          <div className="space-y-8 animate-slideUpFade">
            <div>
              <h2 className="text-2xl font-black text-slate-900">Final Review</h2>
              <p className="text-slate-500 text-sm font-medium">Verify your mandate before publishing to the network.</p>
            </div>

            <div className="bg-slate-50 border border-slate-100 rounded-[40px] overflow-hidden">
               <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-black">{formData.title}</h3>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{formData.difficulty} Task</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-orange-400 font-black uppercase tracking-widest mb-1">Max Reward</p>
                    <p className="text-3xl font-black">₹{formData.reward.toLocaleString()}</p>
                  </div>
               </div>
               <div className="p-8 space-y-4">
                  <p className="text-sm text-slate-600 font-medium leading-relaxed italic">"{formData.description}"</p>
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200">
                     <div>
                       <p className="text-[9px] font-black text-slate-400 uppercase">Deadline</p>
                       <p className="text-xs font-black text-slate-800">{new Date(formData.deadline).toLocaleString()}</p>
                     </div>
                     <div>
                       <p className="text-[9px] font-black text-slate-400 uppercase">Est. Work Time</p>
                       <p className="text-xs font-black text-slate-800">{formData.estimatedTime}</p>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* Footer Navigation */}
        <div className="pt-10 flex gap-4 mt-8 border-t border-slate-50">
          {currentStep > 1 && (
            <button 
              onClick={() => setCurrentStep(prev => (prev - 1) as WizardStep)}
              className="flex-1 py-5 bg-white border-2 border-slate-200 text-slate-400 hover:text-slate-900 hover:border-slate-900 rounded-[24px] font-black text-xs uppercase tracking-widest transition-all"
            >
              Back
            </button>
          )}
          {currentStep < 4 ? (
            <button 
              disabled={!canMoveToNext()}
              onClick={() => setCurrentStep(prev => (prev + 1) as WizardStep)}
              className="flex-grow py-5 bg-slate-900 hover:bg-orange-600 disabled:opacity-20 text-white rounded-[24px] font-black text-xs uppercase tracking-[0.2em] transition-all shadow-xl active:scale-95"
            >
              Next Step
            </button>
          ) : (
            <button 
              onClick={handleSubmit}
              className="flex-grow py-5 bg-orange-600 hover:bg-orange-700 text-white rounded-[24px] font-black text-xs uppercase tracking-[0.2em] transition-all shadow-xl shadow-orange-100 active:scale-95"
            >
              Publish Task Mandate
            </button>
          )}
        </div>
      </div>

      {/* AI Modal (from previous version, reused for better guide) */}
      {proposedRefinement && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setProposedRefinement(null)} />
          <div className="relative bg-white w-full max-w-4xl rounded-[48px] overflow-hidden shadow-2xl animate-scaleIn border border-white max-h-[90vh] flex flex-col">
            <div className="bg-slate-900 p-10 text-white flex justify-between items-center flex-shrink-0">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-orange-600 rounded-3xl flex items-center justify-center text-3xl shadow-lg shadow-orange-950/40">
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                </div>
                <div>
                  <h2 className="text-2xl font-black tracking-tight">AI Task Optimization</h2>
                  <p className="text-orange-400 text-[10px] font-black uppercase tracking-[0.2em]">Accuracy & Reward Clearance</p>
                </div>
              </div>
              <button onClick={() => setProposedRefinement(null)} className="text-slate-500 hover:text-white transition-colors">
                <i className="fa-solid fa-xmark text-2xl"></i>
              </button>
            </div>

            <div className="p-8 md:p-12 overflow-y-auto space-y-10 custom-scrollbar">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Original</h4>
                  <div className="bg-slate-50 border border-slate-100 p-8 rounded-[32px] space-y-4 opacity-50">
                    <p className="text-lg font-black text-slate-800">{formData.title}</p>
                    <p className="text-sm text-slate-500 font-medium leading-relaxed">{formData.description}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-orange-600 uppercase tracking-widest px-2 flex justify-between">
                    Suggested Improvements
                    <span className="bg-orange-100 text-orange-600 px-2 py-0.5 rounded-lg text-[8px] animate-pulse">OPTIMIZED</span>
                  </h4>
                  <div className="bg-orange-50 border-2 border-orange-200 p-8 rounded-[32px] space-y-4 shadow-inner">
                    <p className="text-lg font-black text-slate-900">{proposedRefinement.title}</p>
                    <p className="text-sm text-orange-900 font-medium leading-relaxed">{proposedRefinement.description}</p>
                  </div>
                </div>
              </div>

              {proposedRefinement.reasoning && (
                <div className="bg-slate-900 p-8 rounded-[32px] border border-slate-800 space-y-4 shadow-xl">
                  <h5 className="text-xs font-black text-orange-400 uppercase tracking-widest flex items-center gap-3">
                    <i className="fa-solid fa-brain"></i>
                    Clear Guidance
                  </h5>
                  <p className="text-slate-300 text-sm font-medium leading-relaxed italic">
                    "{proposedRefinement.reasoning}"
                  </p>
                </div>
              )}
            </div>

            <div className="p-10 bg-slate-50 border-t border-slate-100 flex-shrink-0 flex gap-4">
              <button 
                onClick={() => setProposedRefinement(null)}
                className="flex-1 py-5 bg-white border-2 border-slate-200 text-slate-400 hover:text-slate-900 rounded-[24px] font-black text-xs uppercase tracking-widest"
              >
                Keep Original
              </button>
              <button 
                onClick={() => {
                  setFormData({
                    ...formData,
                    title: proposedRefinement.title,
                    description: proposedRefinement.description,
                    reward: proposedRefinement.reward,
                    difficulty: proposedRefinement.difficulty as any,
                    estimatedTime: proposedRefinement.estimatedTime
                  });
                  setProposedRefinement(null);
                }}
                className="flex-1 py-5 bg-orange-600 hover:bg-orange-500 text-white rounded-[24px] font-black text-xs uppercase tracking-widest shadow-xl"
              >
                Apply AI Guidance
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateTask;


import React, { useState, useEffect, useMemo } from 'react';
import { Transaction, TransactionType, Task, UserProfile } from '../types';
import { cloud } from '../services/cloudService';

const AdminAuditPanel: React.FC = () => {
  const [globalTxs, setGlobalTxs] = useState<Transaction[]>([]);
  const [globalTasks, setGlobalTasks] = useState<Task[]>([]);
  const [globalUsers, setGlobalUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'transactions' | 'market' | 'statement' | 'users'>('transactions');
  const [filter, setFilter] = useState<'All' | 'Pending' | 'Completed' | 'Failed'>('Pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [dealSearchQuery, setDealSearchQuery] = useState('');

  const refreshData = async () => {
    setLoading(true);
    const txs = await cloud.fetchAllGlobalTransactions();
    const tasks = await cloud.fetchGlobalTasks();
    const users = await cloud.fetchAllUsers();
    setGlobalTxs(txs);
    setGlobalTasks(tasks);
    setGlobalUsers(users);
    setLoading(false);
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleApprove = async (txId: string) => {
    if (!window.confirm("Verify: Does this deposit match your official UPI Statement? (Statement Auditing Protocol)")) return;
    await cloud.approveTransaction(txId);
    refreshData();
  };

  const handleReject = async (txId: string) => {
    if (!window.confirm("Reject: Terminate this request for failing verification against UPI statement?")) return;
    await cloud.rejectTransaction(txId);
    refreshData();
  };

  const handleCancelDeal = async (taskId: string) => {
    const reason = window.prompt("Reason for Cancellation (Legal/Regulation/Deregulation):", "Under Act of Govt of India - Policy Violation");
    if (!reason) return;

    if (window.confirm("AUTHORITY ACTION: Terminating this deal under Government of India Acts and network policy. Proceeed?")) {
      await cloud.cancelDeal(taskId, reason);
      refreshData();
    }
  };

  const filteredTxs = useMemo(() => {
    return globalTxs.filter(tx => {
      const matchesFilter = filter === 'All' || tx.status === filter;
      const matchesSearch = 
        tx.userName?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        tx.utr?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [globalTxs, filter, searchQuery]);

  const filteredUsers = useMemo(() => {
    return globalUsers.filter(u => 
      u.username.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearchQuery.toLowerCase())
    );
  }, [globalUsers, userSearchQuery]);

  const filteredDeals = useMemo(() => {
    const activeDeals = globalTasks.filter(t => t.status === 'In Progress' || t.status === 'Awarded');
    if (!dealSearchQuery) return activeDeals;
    return activeDeals.filter(t => 
      t.title.toLowerCase().includes(dealSearchQuery.toLowerCase()) ||
      t.creatorName?.toLowerCase().includes(dealSearchQuery.toLowerCase()) ||
      t.winnerName?.toLowerCase().includes(dealSearchQuery.toLowerCase())
    );
  }, [globalTasks, dealSearchQuery]);

  const stats = useMemo(() => {
    const totalLiquidity = globalTxs.reduce((acc, tx) => tx.status === 'Completed' && (tx.type === TransactionType.DEPOSIT) ? acc + tx.amount : acc, 0);
    const networkRevenue = globalTxs.reduce((acc, tx) => (tx.type === TransactionType.LOGIN_FEE) ? acc + tx.amount : acc, 0);
    const pendingDeposits = globalTxs.reduce((acc, tx) => (tx.status === 'Pending' && tx.type === TransactionType.DEPOSIT) ? acc + tx.amount : acc, 0);
    const activeContractValue = globalTasks.filter(t => t.status === 'In Progress' || t.status === 'Awarded').reduce((acc, t) => acc + (t.highestBid || t.reward), 0);
    return { totalLiquidity, networkRevenue, pendingDeposits, activeContractValue };
  }, [globalTxs, globalTasks]);

  return (
    <div className="space-y-8 animate-fadeIn max-w-7xl mx-auto pb-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-indigo-600 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">Host Authority</span>
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Compliance Audit Gateway</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Statement & Deal Auditor</h1>
          <p className="text-slate-500 font-medium">Reconcile every task and transaction against UPI statement evidence.</p>
        </div>
        <button 
          onClick={refreshData}
          className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl flex items-center gap-2"
        >
          <i className={`fa-solid fa-rotate ${loading ? 'animate-spin' : ''}`}></i>
          Re-Sync Cloud Data
        </button>
      </header>

      {/* Authority Toggles */}
      <div className="flex flex-wrap bg-slate-100 p-1 rounded-2xl border border-slate-200 w-fit">
        <button onClick={() => setActiveTab('transactions')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'transactions' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500'}`}>Transaction Ledger</button>
        <button onClick={() => setActiveTab('market')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'market' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500'}`}>Deal Compliance</button>
        <button onClick={() => setActiveTab('users')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'users' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500'}`}>User Directory</button>
        <button onClick={() => setActiveTab('statement')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'statement' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500'}`}>Statement Reconcile</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Total System Liquidity</p>
          <h3 className="text-2xl font-black text-slate-900">₹{stats.totalLiquidity.toLocaleString('en-IN')}</h3>
          <p className="text-[9px] text-green-600 font-bold mt-2">Verified Bank Settlements</p>
        </div>
        <div className="bg-indigo-900 p-8 rounded-[40px] shadow-sm text-white border border-indigo-800">
          <p className="text-[10px] text-indigo-300 font-black uppercase tracking-widest mb-1">Screentime Tax Revenue</p>
          <h3 className="text-2xl font-black text-amber-400">₹{stats.networkRevenue.toLocaleString('en-IN')}</h3>
          <p className="text-[9px] text-indigo-400 font-bold mt-2">Maintenance Allocation</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm border-l-4 border-l-amber-500">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Awaiting UPI Match</p>
          <h3 className="text-2xl font-black text-amber-600">₹{stats.pendingDeposits.toLocaleString('en-IN')}</h3>
          <p className="text-[9px] text-amber-500 font-bold mt-2">Audit Access Required</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm border-l-4 border-l-indigo-500">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Circulating Contract Value</p>
          <h3 className="text-2xl font-black text-indigo-600">₹{stats.activeContractValue.toLocaleString('en-IN')}</h3>
          <p className="text-[9px] text-indigo-500 font-bold mt-2">Locked in Escrow</p>
        </div>
      </div>

      {activeTab === 'transactions' && (
        <section className="bg-white rounded-[40px] border border-slate-100 overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-slate-50 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex bg-slate-50 p-1 rounded-2xl border border-slate-100">
              {(['All', 'Pending', 'Completed', 'Failed'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${filter === f ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400'}`}>{f}</button>
              ))}
            </div>
            <div className="relative w-full md:w-72">
              <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input type="text" placeholder="Search Ref ID or User..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-11 pr-10 py-3 bg-slate-50 border-none rounded-2xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all" />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-600">
                  <i className="fa-solid fa-circle-xmark"></i>
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                  <th className="px-8 py-6">User / Ref ID</th>
                  <th className="px-8 py-6">Type</th>
                  <th className="px-8 py-6">Amount</th>
                  <th className="px-8 py-6">Audit Evidence (UTR)</th>
                  <th className="px-8 py-6">Status</th>
                  <th className="px-8 py-6 text-right">Audit Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredTxs.length === 0 ? (
                  <tr><td colSpan={6} className="px-8 py-20 text-center italic text-slate-400 font-bold">No transactions match your search criteria.</td></tr>
                ) : (
                  filteredTxs.map(tx => (
                    <tr key={tx.id} className="text-sm hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                          <span className="font-black text-slate-900">{tx.userName}</span>
                          <span className="text-[10px] font-mono text-slate-400">{tx.id}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                          tx.type === TransactionType.LOGIN_FEE ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {tx.type}
                        </span>
                      </td>
                      <td className="px-8 py-6 font-black text-lg">₹{tx.amount.toLocaleString()}</td>
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-indigo-600 uppercase">{tx.description}</span>
                          <span className="font-mono text-xs text-slate-400">{tx.utr || 'Auto-Deduct'}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6"><span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${tx.status === 'Completed' ? 'bg-green-100 text-green-700' : tx.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>{tx.status}</span></td>
                      <td className="px-8 py-6 text-right">
                        {tx.status === 'Pending' && (
                          <div className="flex gap-2 justify-end">
                            <button onClick={() => handleReject(tx.id)} className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all"><i className="fa-solid fa-xmark"></i></button>
                            <button onClick={() => handleApprove(tx.id)} className="w-10 h-10 rounded-xl bg-green-50 text-green-600 flex items-center justify-center hover:bg-green-600 hover:text-white transition-all"><i className="fa-solid fa-check"></i></button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === 'users' && (
        <section className="bg-white rounded-[40px] border border-slate-100 overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-slate-50 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
               <h3 className="text-xl font-black text-slate-900 tracking-tight">Audit User Directory</h3>
               <p className="text-xs text-slate-400 font-medium">Monitoring {globalUsers.length} network participants</p>
            </div>
            <div className="relative w-full md:w-96">
              <i className="fa-solid fa-user-magnifying absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500"></i>
              <input 
                type="text" 
                placeholder="Search by username or email..." 
                value={userSearchQuery} 
                onChange={(e) => setUserSearchQuery(e.target.value)} 
                className="w-full pl-11 pr-10 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl text-sm font-bold outline-none focus:border-indigo-500 transition-all shadow-inner" 
              />
              {userSearchQuery && (
                <button onClick={() => setUserSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-600">
                  <i className="fa-solid fa-circle-xmark"></i>
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                  <th className="px-8 py-6">Professional Profile</th>
                  <th className="px-8 py-6">Verified Balance</th>
                  <th className="px-8 py-6">Engagement</th>
                  <th className="px-8 py-6">Network Tier</th>
                  <th className="px-8 py-6 text-right">Audit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredUsers.length === 0 ? (
                  <tr><td colSpan={5} className="px-8 py-20 text-center italic text-slate-400 font-bold">No user profiles match your search criteria.</td></tr>
                ) : (
                  filteredUsers.map(user => (
                    <tr key={user.id} className="text-sm hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <img 
                            src={user.profilePic || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} 
                            alt="Avatar" 
                            className="w-10 h-10 rounded-xl bg-slate-100 object-cover"
                          />
                          <div className="flex flex-col">
                            <span className="font-black text-slate-900">{user.username}</span>
                            <span className="text-[10px] text-slate-400 font-medium">{user.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 font-black text-lg text-indigo-600">₹{user.balance.toLocaleString('en-IN')}</td>
                      <td className="px-8 py-6">
                         <div className="flex flex-col">
                            <span className="text-xs font-bold text-slate-700">{user.completedTasks} Tasks Done</span>
                            <span className="text-[10px] text-amber-500 font-black uppercase">{user.rating.toFixed(1)} Portal Rating</span>
                         </div>
                      </td>
                      <td className="px-8 py-6">
                         <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${user.isAdmin ? 'bg-indigo-900 text-white border-indigo-700' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                           {user.isAdmin ? 'Host Authority' : 'Professional'}
                         </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <button className="bg-white border border-slate-200 hover:border-indigo-500 text-slate-400 hover:text-indigo-600 p-2 rounded-xl transition-all">
                          <i className="fa-solid fa-folder-open"></i>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === 'market' && (
        <section className="bg-white rounded-[40px] border border-slate-100 overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-slate-50 bg-rose-50/30 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-lg font-black text-rose-900 tracking-tight flex items-center gap-3">
                <i className="fa-solid fa-scale-balanced"></i>
                Peer-to-Peer Agreement Oversight
              </h3>
              <p className="text-xs text-rose-700 mt-1 font-medium italic">Cancellation authority active under Act of Govt of India.</p>
            </div>
            <div className="relative w-full md:w-80">
              <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-rose-400"></i>
              <input 
                type="text" 
                placeholder="Search deals or participants..." 
                value={dealSearchQuery} 
                onChange={(e) => setDealSearchQuery(e.target.value)} 
                className="w-full pl-11 pr-10 py-3 bg-white border-2 border-rose-100 rounded-2xl text-xs font-bold outline-none focus:border-rose-500 transition-all shadow-sm" 
              />
              {dealSearchQuery && (
                <button onClick={() => setDealSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-rose-300 hover:text-rose-600">
                  <i className="fa-solid fa-circle-xmark"></i>
                </button>
              )}
            </div>
          </div>
          <div className="overflow-x-auto">
             <table className="w-full text-left">
               <thead>
                 <tr className="bg-slate-50/50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                   <th className="px-8 py-6">Task Mandate</th>
                   <th className="px-8 py-6">Offerer</th>
                   <th className="px-8 py-6">Winner (Fulfiller)</th>
                   <th className="px-8 py-6">Contract Value</th>
                   <th className="px-8 py-6">Status</th>
                   <th className="px-8 py-6 text-right">Host Override</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                 {filteredDeals.length === 0 ? (
                   <tr><td colSpan={6} className="px-8 py-20 text-center italic text-slate-400 font-bold">No active contracts match your search.</td></tr>
                 ) : (
                   filteredDeals.map(deal => (
                     <tr key={deal.id} className="text-sm hover:bg-rose-50/20 transition-colors">
                       <td className="px-8 py-6">
                         <div className="flex flex-col">
                            <span className="font-black text-slate-800">{deal.title}</span>
                            <span className="text-[10px] text-slate-400 uppercase font-bold">{deal.difficulty}</span>
                         </div>
                       </td>
                       <td className="px-8 py-6 font-bold text-orange-600">{deal.creatorName}</td>
                       <td className="px-8 py-6 font-bold text-indigo-600">{deal.winnerName || 'Auction Desk'}</td>
                       <td className="px-8 py-6 font-black text-lg">₹{(deal.highestBid || deal.reward).toLocaleString()}</td>
                       <td className="px-8 py-6"><span className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">{deal.status}</span></td>
                       <td className="px-8 py-6 text-right">
                         <button 
                           onClick={() => handleCancelDeal(deal.id)}
                           className="bg-rose-600 hover:bg-rose-700 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-rose-100"
                         >
                           Cancel Deal
                         </button>
                       </td>
                     </tr>
                   ))
                 )}
               </tbody>
             </table>
          </div>
        </section>
      )}

      {activeTab === 'statement' && (
        <section className="bg-white rounded-[40px] border border-slate-100 p-12 shadow-2xl text-center space-y-8">
           <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center text-3xl mx-auto shadow-inner">
             <i className="fa-solid fa-file-invoice-dollar"></i>
           </div>
           <div className="max-w-md mx-auto space-y-4">
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Host Statement Upload</h3>
              <p className="text-sm text-slate-500 font-medium">Reconcile portal wallet requests with actual UPI Bank Statements.</p>
           </div>
           <div className="border-2 border-dashed border-indigo-100 rounded-[32px] p-20 bg-indigo-50/30">
              <input type="file" id="statement-upload" className="hidden" />
              <label htmlFor="statement-upload" className="cursor-pointer">
                <div className="flex flex-col items-center gap-4">
                  <i className="fa-solid fa-cloud-arrow-up text-4xl text-indigo-400"></i>
                  <span className="text-sm font-black uppercase tracking-widest text-indigo-600">Import Official Bank CSV/PDF</span>
                </div>
              </label>
           </div>
           <div className="bg-slate-900 p-8 rounded-[32px] text-left">
              <h4 className="text-white font-black text-sm mb-4 flex items-center gap-2">
                <i className="fa-solid fa-circle-info text-amber-400"></i>
                Audit Compliance Protocol
              </h4>
              <ul className="text-xs text-slate-400 space-y-3 font-medium">
                <li>• Every deposit must have a matching UTR in the official host statement.</li>
                <li>• Screen-time taxes (1 COIN @ 100s) are non-refundable and allocated to system maintenance.</li>
                <li>• All opportunities are gated by the audited balance; users cannot offer rewards beyond verified liquidity.</li>
              </ul>
           </div>
        </section>
      )}
    </div>
  );
};

export default AdminAuditPanel;
